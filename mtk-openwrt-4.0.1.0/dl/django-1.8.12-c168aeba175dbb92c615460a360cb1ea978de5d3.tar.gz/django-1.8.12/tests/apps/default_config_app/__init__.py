default_app_config = 'apps.default_config_app.apps.CustomConfig'
