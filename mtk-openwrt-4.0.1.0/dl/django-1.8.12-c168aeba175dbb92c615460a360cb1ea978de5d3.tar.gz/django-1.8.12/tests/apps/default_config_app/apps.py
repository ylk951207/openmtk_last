from django.apps import AppConfig


class CustomConfig(AppConfig):
    name = 'apps.default_config_app'
